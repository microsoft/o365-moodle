<#
    File Name :  Moodle-AzureAD-Script.ps1
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the MIT License.
#>

# Allow for the script to be run
Write-Host "Deployment started..." -ForegroundColor Green
Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Scope CurrentUser

# Install necessary modules
Write-Host "Installing required packages..." -ForegroundColor Cyan
Install-Module AzureAD -AllowClobber -Scope CurrentUser
Install-Module Az -AllowClobber -Scope CurrentUser
Write-Host "Installation completed" -ForegroundColor Cyan

# Check if Azure CLI is installed.
    Write-Host "Checking if Azure CLI is installed." -ForegroundColor Green
    $localPath = [Environment]::GetEnvironmentVariable("ProgramFiles(x86)")
    if ($localPath -eq $null) {
        $localPath = "C:\Program Files (x86)"
    }

    $localPath = $localPath + "\Microsoft SDKs\Azure\CLI2"
    If (-not(Test-Path -Path $localPath)) {
        Write-Host "Azure CLI is not installed!" -ForegroundColor Green
        $confirmationtitle      = "Please select YES to install Azure CLI."
        $confirmationquestion   = "Do you want to proceed?"
        $confirmationchoices    = "&yes", "&no" # 0 = yes, 1 = no
            
        $updatedecision = $host.ui.promptforchoice($confirmationtitle, $confirmationquestion, $confirmationchoices, 1)
        if ($updatedecision -eq 0) {
            Write-Host "Installing Azure CLI ..." -ForegroundColor Cyan
            Invoke-WebRequest -Uri https://aka.ms/installazurecliwindows -OutFile .\AzureCLI.msi; Start-Process msiexec.exe -Wait -ArgumentList '/I AzureCLI.msi /quiet'; rm .\AzureCLI.msi
            Write-Host "Azure CLI is installed! Please close this PowerShell window and re-run this script in a new PowerShell session." -ForegroundColor Green
            EXIT
        } else {
            Write-Host "Azure CLI is not installed.`nPlease install the CLI from https://docs.microsoft.com/en-us/cli/azure/install-azure-cli?view=azure-cli-latest and re-run this script in a new PowerShell session" -ForegroundColor DarkRed
            EXIT
        }
    } else {
        Write-Host "Azure CLI is installed." -ForegroundColor Green
    }

#Overarching requirement - log into Azure first!
Write-Host "You would get an pop up to login to azure" -ForegroundColor Yellow
Connect-AzureAD

Write-Host "Please continue the login in the web browser that will open" -ForegroundColor Yellow
az login --allow-no-subscriptions

<#
.DESCRIPTION 
This function will be able to create an array of type RequiredResourceAccess which will be then passed to the New-AzureADApplication cmdlet
#>
function Get-Resources
{
    [Microsoft.Open.AzureAD.Model.RequiredResourceAccess[]] $outputArray = @();
    
    $localPath = Get-Location
    $jsonPath = -Join($localPath,'\Json\permissions.json');
    $jsonObj = (New-Object System.Net.WebClient).DownloadString($jsonPath) | ConvertFrom-Json;
    # Output the number of objects to push into the array outputArray
    Write-Host 'From the json path:'$jsonPath', we can find' $jsonObj.requiredResourceAccess.length'attributes to populate' -ForegroundColor Green;
    for ($i = 0; $i -lt $jsonObj.requiredResourceAccess.length; $i++) {
        
        # Step A - Create a new object fo the type RequiredResourceAccess
        $reqResourceAccess = New-Object -TypeName Microsoft.Open.AzureAD.Model.RequiredResourceAccess; 
        # Step B - Straightforward setting the ResourceAppId accordingly
        $reqResourceAccess.ResourceAppId = $jsonObj.requiredResourceAccess[$i].resourceAppId;
        # Step C - Having to set the ResourceAccess carefully
        if ($jsonObj.requiredResourceAccess[$i].resourceAccess.length -gt 1)
        {
            $reqResourceAccess.ResourceAccess = $jsonObj.requiredResourceAccess[$i].resourceAccess;
        }
        else
        {
            $reqResourceAccess.ResourceAccess = $jsonObj.requiredResourceAccess[$i].resourceAccess[0];
        }
        # Step D - Add the element to the array
        $outputArray += $reqResourceAccess;
    }
    $outputArray;
}

<#
.DESCRIPTION 
This function will allow to create and add Microsoft Graph scope 
#>
function Create-Scope(
        [string] $value,
        [string] $userConsentDisplayName,
        [string] $userConsentDescription,
        [string] $adminConsentDisplayName,
        [string] $adminConsentDescription) {
        $scope = New-Object Microsoft.Open.MsGraph.Model.PermissionScope
        $scope.Id = New-Guid
        $scope.Value = $value
        $scope.UserConsentDisplayName = $userConsentDisplayName
        $scope.UserConsentDescription = $userConsentDescription
        $scope.AdminConsentDisplayName = $adminConsentDisplayName
        $scope.AdminConsentDescription = $adminConsentDescription
        $scope.IsEnabled = $true
        $scope.Type = "User"
        return $scope
    }

<#
.DESCRIPTION 
This function will allow to add preauthroized application for Azure AD application 
#>
function Create-PreAuthorizedApplication(
        [string] $applicationIdToPreAuthorize,
        [string] $scopeId) {
        $preAuthorizedApplication = New-Object 'Microsoft.Open.MSGraph.Model.PreAuthorizedApplication'
        $preAuthorizedApplication.AppId = $applicationIdToPreAuthorize
        $preAuthorizedApplication.DelegatedPermissionIds = @($scopeId)
        return $preAuthorizedApplication
    }

function IsValidateSecureUrl {
    param(
        [Parameter(Mandatory = $true)] [string] $url
    )
    # Url with https prefix REGEX matching
    return ($url -match "https:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)")
}

# Grant Admin consent
function GrantAdminConsent {
    Param(
        [Parameter(Mandatory = $true)] $appId
        )

    $confirmationTitle = "Admin consent permissions is required for app registration using CLI"
    $confirmationQuestion = "Do you want to grant admin consent?"
    $confirmationChoices = "&Yes", "&No" # 0 = Yes, 1 = No
    $consentErrorMessage = "Current user does not have the privilege to consent the below permissions on this app.
    * AppCatalog.Read.All(Delegated)
    * Group.Read.All(Delegated)
    * Group.Read.All(Application)
    * TeamsAppInstallation.ReadWriteForUser.All(Application)
    * User.Read.All(Delegated)
    * User.Read(Application) 
    Please ask the tenant's global administrator to consent."

    $updateDecision = $Host.UI.PromptForChoice($confirmationTitle, $confirmationQuestion, $confirmationChoices, 1)
    if ($updateDecision -eq 0) {
        # Grant admin consent for app registration required permissions using CLI
        Write-Host "Waiting for admin consent to finish..." -ForegroundColor Green
        az ad app permission admin-consent --id $appId
        
        if ($LASTEXITCODE -ne 0) {
            Write-Host $consentErrorMessage -ForegroundColor Red
        } else {
            Write-Host "Admin consent has been granted." -ForegroundColor Green
        }
    }
}

# Step 1 - Getting the necessary information
$displayName = Read-Host -Prompt "Enter the AAD app name (ex: Moodle plugin)"
$moodleUrl = Read-Host -Prompt "Enter the URL of your Moodle server (ex: https://www.moodleserver.com)"

if(-not(IsValidateSecureUrl($moodleUrl)))
{
    Write-Host "The URL is incorrect and should start with HTTPS" -ForegroundColor Red
}

if ($moodleUrl -notmatch '.+?\/$')
{
    $moodleUrl += '/'
}

# Step 2 - Construct the reply URLs
$botFrameworkUrl = 'https://token.botframework.com/.auth/web/redirect'
$authUrl = $moodleUrl + 'auth/oidc/'
$endUrl = $moodleUrl + 'local/o365/sso_end.php'
$replyUrls = ($moodleUrl, $botFrameworkUrl, $authUrl, $endUrl)

# Step 3 - Compile the Required Resource Access object
[Microsoft.Open.AzureAD.Model.RequiredResourceAccess[]] $requiredResourceAccess = Get-Resources

# Step 4 - Making sure to officially register the application
$app = New-AzureADApplication -DisplayName $displayName 
$appId = $app.AppId
$appObjectId = $app.ObjectId
Write-Host "App registered with Appid: " $appId -ForegroundColor Green

# Removing default scope user_impersonation, access and optional claims
Write-Host "Removing default scope user_impersonation" -ForegroundColor Green
$localPath = Get-Location
$resetOptionalClaimPath = -Join($localPath,'\Json\AadOptionalClaims_Reset.json');
$DEFAULT_SCOPE=$(az ad app show --id $appId | .\jq '.oauth2Permissions[0].isEnabled = false' | .\jq -r '.oauth2Permissions')
$DEFAULT_SCOPE>>scope.json
az ad app update --id $appId --set oauth2Permissions=@scope.json
Remove-Item .\scope.json
az ad app update --id $appId --remove oauth2Permissions
az ad app update --id $appId --remove replyUrls 
az ad app update --id $appId --remove IdentifierUris
az ad app update --id $appId --optional-claims $resetOptionalClaimPath
az ad app update --id $appId --remove requiredResourceAccess
Write-Host "Removed default scope user_impersonation" -ForegroundColor Green

# updating reply urls and api permissions
Set-AzureADApplication -ObjectId $appObjectId -ReplyUrls $replyUrls -RequiredResourceAccess $requiredResourceAccess
Write-Host "Reply urls and api permissions added" -ForegroundColor Green

# Grant Admin consent 
GrantAdminConsent $appId

# setting AAD optional claims:
$localPath = Get-Location
$setOptionalClaimPath = -Join($localPath,'\Json\AadOptionalClaims.json');
az ad app update --id $appId --optional-claims $setOptionalClaimPath
az ad app update --id $appId --set oauth2AllowImplicitFlow=true
Write-Host "AAD optional claims updated" -ForegroundColor Green 

# Step 5 - Taking the object id generated in Step 2, create a new Password
$pwdVars = New-AzureADApplicationPasswordCredential -ObjectId $app.ObjectId
Write-Host "Client secret generated" -ForegroundColor Green

# Step 5a - Updating the logo for the Azure AD app
$location = Get-Location
$imgLocation = -Join($location, '\Assets\moodle-logo.jpg')
Set-AzureADApplicationLogo -ObjectId $app.ObjectId -FilePath $imgLocation

# Step 5b - Add expose an API 
# Reference https://docs.microsoft.com/en-us/answers/questions/29893/azure-ad-teams-dev-how-to-automate-the-app-registr.html
# Expose an API
$msApplication = Get-AzureADMSApplication -ObjectId $appObjectId

# Set identifier URL
if($moodleUrl -imatch 'https://'){
  $identifierUris = 'api://' + $moodleUrl.Remove(0,8) + $appId
}
Set-AzureADMSApplication -ObjectId $msApplication.Id -IdentifierUris $identifierUris
Write-Host "AppId url added" -ForegroundColor Green
                          
# Create access_as_user scope
$scopes = New-Object System.Collections.Generic.List[Microsoft.Open.MsGraph.Model.PermissionScope]
$msApplication.Api.Oauth2PermissionScopes | foreach-object { $scopes.Add($_) }
$scope = Create-Scope -value "access_as_user"  `
    -userConsentDisplayName "Teams can access the user profile and make requests on the user's behalf"  `
    -userConsentDescription "Enable Teams to call this app�s APIs with the same rights as the user"  `
    -adminConsentDisplayName "Teams can access the user�s profile"  `
    -adminConsentDescription "Allows Teams to call the app�s web APIs as the current user"
$scopes.Add($scope)
$msApplication.Api.Oauth2PermissionScopes = $scopes
Set-AzureADMSApplication -ObjectId $msApplication.Id -Api $msApplication.Api
Write-Host "Scope access_as_user added." -ForegroundColor Green
             
# Authorize Teams mobile/desktop client and Teams web client to access API
$preAuthorizedApplications = New-Object 'System.Collections.Generic.List[Microsoft.Open.MSGraph.Model.PreAuthorizedApplication]'
$teamsRichClientPreauthorization = Create-PreAuthorizedApplication `
    -applicationIdToPreAuthorize '1fec8e78-bce4-4aaf-ab1b-5451cc387264' `
    -scopeId $scope.Id
$teamsWebClientPreauthorization = Create-PreAuthorizedApplication `
    -applicationIdToPreAuthorize '5e3ce6c0-2b1f-4285-8d4b-75ee78787346' `
    -scopeId $scope.Id
$preAuthorizedApplications.Add($teamsRichClientPreauthorization)
$preAuthorizedApplications.Add($teamsWebClientPreauthorization)
$msApplication.Api.PreAuthorizedApplications = $preAuthorizedApplications
Set-AzureADMSApplication -ObjectId $msApplication.Id -Api $msApplication.Api
Write-Host "Teams mobile/desktop and web clients applications pre-authorized." -ForegroundColor Green

# Step 6 - Write out the newly generated app Id and azure app password
Write-Host 'Your AD Application ID: '$appId
Write-Host 'Your AD Application Secret: '$pwdVars.Value
Write-Host 'Deployment ended'-ForegroundColor Green
