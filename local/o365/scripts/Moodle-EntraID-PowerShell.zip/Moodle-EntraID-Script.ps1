# File Name: Moodle-EntraID-Script.ps1
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the GPLv3 License.

#Requires -Version 7.0

[CmdletBinding()]
param()

# Initialize
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'Continue'
$InformationPreference = 'Continue'

# Helper Functions
function Write-StatusMessage {
    param(
        [string]$Message,
        [string]$Color = 'Green'
    )
    Write-Host $Message -ForegroundColor $Color
}

function Invoke-WithRetry {
    param(
        [Parameter(Mandatory)]
        [scriptblock]$ScriptBlock,
        [int]$MaxAttempts = 5,
        [int]$DelaySeconds = 3,
        [string]$OperationName = "Operation"
    )
    
    for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {
        try {
            return & $ScriptBlock
        }
        catch {
            if ($attempt -eq $MaxAttempts) {
                Write-StatusMessage "$OperationName failed after $MaxAttempts attempts: $_" -Color Red
                throw
            }
            Write-StatusMessage "Attempt $attempt of $MaxAttempts failed. Retrying in $DelaySeconds seconds..." -Color Yellow
            Start-Sleep -Seconds $DelaySeconds
        }
    }
}

function Import-RequiredModules {
    Write-StatusMessage "Installing and importing required modules..." -Color Cyan

    # Force specific version for all Microsoft.Graph modules
    # Version 2.25.0 is the latest stable version
    $graphVersion = "2.25.0"

    # List of required sub-modules
    $requiredModules = @(
        'Microsoft.Graph.Applications',
        'Microsoft.Graph.Users',
        'Microsoft.Graph.Identity.SignIns',
        'Microsoft.Graph.Identity.DirectoryManagement'
    )

    # Ensure module auto-loading is disabled to avoid triggering corrupted modules
    Write-StatusMessage "Preparing module environment..." -Color Cyan

    # Import PowerShellGet first before disabling auto-loading
    Import-Module PowerShellGet -Force -ErrorAction Stop

    $originalAutoLoading = $PSModuleAutoLoadingPreference
    $global:PSModuleAutoLoadingPreference = 'None'

    # Resolve user-scoped PowerShell base path (cross-platform)
    if ($IsWindows) {
        $psUserBasePath = Join-Path ([System.Environment]::GetFolderPath('MyDocuments')) 'PowerShell'
    } else {
        $psUserBasePath = Join-Path $HOME '.local/share/powershell'
    }

    # Clear PowerShell module analysis cache
    $moduleCachePath = Join-Path $psUserBasePath 'ModuleAnalysisCache'
    if (Test-Path $moduleCachePath) {
        Write-StatusMessage "Clearing module analysis cache..." -Color Cyan
        Remove-Item -Path $moduleCachePath -Recurse -Force -ErrorAction SilentlyContinue
    }

    # Clear PSModulePath cache and module table
    Write-StatusMessage "Resetting module path cache..." -Color Cyan
    $ExecutionContext.InvokeCommand.GetCmdlets() | Out-Null

    # Remove all modules from memory
    $modulesToRemove = @(Get-Module | Where-Object { $_.Name -like "Microsoft.Graph*" })
    if ($modulesToRemove.Count -gt 0) {
        Write-StatusMessage "Unloading $($modulesToRemove.Count) Microsoft.Graph modules from memory..." -Color Cyan
        $modulesToRemove | ForEach-Object { Remove-Module $_.Name -Force -ErrorAction SilentlyContinue }
    }

    # First pass: Remove all non-2.25.0 versions of ALL Microsoft.Graph modules
    Write-StatusMessage "Cleaning up all Microsoft.Graph modules..." -Color Cyan
    $allGraphModulesPath = Join-Path $psUserBasePath 'Modules'
    if (Test-Path $allGraphModulesPath) {
        $graphModules = Get-ChildItem -Path $allGraphModulesPath -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -like "Microsoft.Graph.*" }
        foreach ($graphModule in $graphModules) {
            $versions = Get-ChildItem -Path $graphModule.FullName -Directory -ErrorAction SilentlyContinue
            foreach ($versionDir in $versions) {
                if ($versionDir.Name -ne $graphVersion) {
                    Write-StatusMessage "Removing $($graphModule.Name) version $($versionDir.Name)..." -Color Yellow
                    Remove-Item -Path $versionDir.FullName -Recurse -Force -ErrorAction SilentlyContinue
                }
            }
        }
    }

    try {
        foreach ($module in $requiredModules) {
            # Use filesystem to check for installed versions directly to avoid triggering Get-Module issues
            $moduleBasePath = Join-Path $psUserBasePath "Modules/$module"
            $targetVersionPath = Join-Path $moduleBasePath $graphVersion

            # Check if the correct version is already installed
            if (Test-Path $targetVersionPath) {
                # Verify it's a valid installation by checking for the manifest file
                $manifestPath = Join-Path $targetVersionPath "$module.psd1"
                if (Test-Path $manifestPath) {
                    Write-StatusMessage "Loading $module version $graphVersion..." -Color Cyan
                } else {
                    Write-StatusMessage "Reinstalling $module version $graphVersion (corrupted)..." -Color Yellow
                    Remove-Item -Path $targetVersionPath -Recurse -Force -ErrorAction SilentlyContinue
                    Install-Module -Name $module -RequiredVersion $graphVersion -Scope CurrentUser -Force -AllowClobber -SkipPublisherCheck
                }
            } else {
                Write-StatusMessage "Installing $module version $graphVersion..." -Color Yellow
                Install-Module -Name $module -RequiredVersion $graphVersion -Scope CurrentUser -Force -AllowClobber -SkipPublisherCheck
            }

            # Import the specific version with explicit path
            if (Test-Path $targetVersionPath) {
                $psd1Path = Join-Path $targetVersionPath "$module.psd1"
                if (Test-Path $psd1Path) {
                    try {
                        # Use -RequiredVersion to ensure we get the right version
                        Import-Module -Name $module -RequiredVersion $graphVersion -Force -Global -ErrorAction Stop
                    } catch {
                        Write-StatusMessage "Standard import failed, trying direct path import..." -Color Yellow
                        # If that fails, try importing by full path
                        Import-Module -Name $psd1Path -Force -Global -ErrorAction Stop
                    }
                } else {
                    throw "Module manifest not found at $psd1Path"
                }
            } else {
                throw "Failed to find installed module $module version $graphVersion at $targetVersionPath"
            }
        }
    }
    finally {
        # Restore module auto-loading preference
        $global:PSModuleAutoLoadingPreference = $originalAutoLoading
    }

    Write-StatusMessage "Module installation completed"
}

function Get-Resources {
    [OutputType([Microsoft.Graph.PowerShell.Models.MicrosoftGraphRequiredResourceAccess[]])]
    param()
    
    $outputArray = @()
    $jsonPath = Join-Path (Get-Location) 'Json\permissions.json'
    
    try {
        $jsonContent = Get-Content $jsonPath -Raw
        $jsonObj = $jsonContent | ConvertFrom-Json
        
        foreach ($resource in $jsonObj.requiredResourceAccess) {
            $reqResourceAccess = [Microsoft.Graph.PowerShell.Models.MicrosoftGraphRequiredResourceAccess]::new()
            $reqResourceAccess.ResourceAppId = $resource.resourceAppId
            
            $resourceAccessArray = $resource.resourceAccess | ForEach-Object {
                $access = [Microsoft.Graph.PowerShell.Models.MicrosoftGraphResourceAccess]::new()
                $access.Id = $_.id
                $access.Type = $_.type
                $access
            }
            
            $reqResourceAccess.ResourceAccess = $resourceAccessArray
            $outputArray += $reqResourceAccess
        }
    }
    catch {
        Write-StatusMessage "Failed to process permissions.json: $_" -Color Red
        throw
    }
    
    return $outputArray
}

function Test-SecureUrl {
    param(
        [Parameter(Mandatory)]
        [string]$Url
    )
    return $Url -match "^https:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)$"
}

function Get-MoodleUrl {
    do {
        $url = Read-Host -Prompt "Enter the URL of your Moodle server (ex: https://www.moodleserver.com)"
        if (-not(Test-SecureUrl $url)) {
            Write-StatusMessage "Invalid URL. Please enter a valid HTTPS URL." -Color Red
            continue
        }
        return $url.TrimEnd('/') + '/'
    } while ($true)
}

function Grant-AdminConsent {
    param(
        [Parameter(Mandatory)]
        [string]$ApplicationId
    )
    
    $title = "Admin Consent Required"
    $question = "Do you want to grant admin consent for the application?"
    
    $choices = @(
        [System.Management.Automation.Host.ChoiceDescription]::new("&Yes", "Grant admin consent")
        [System.Management.Automation.Host.ChoiceDescription]::new("&No", "Skip admin consent")
    )
    
    $decision = $Host.UI.PromptForChoice($title, $question, $choices, 0)
    
    if ($decision -eq 0) {
        Write-StatusMessage "Granting admin consent..." -Color Green
        Start-Sleep -Seconds 20 # Allow time for app registration to propagate
        
        # Get the application
        $app = Get-MgApplication -ApplicationId $ApplicationId
        
        # Ensure service principal exists
        $servicePrincipal = Get-MgServicePrincipal -Filter "appId eq '$($app.AppId)'"
        if (-not $servicePrincipal) {
            $servicePrincipal = New-MgServicePrincipal -AppId $app.AppId
            Start-Sleep -Seconds 10
        }

        $hasError = $false
        foreach ($resourceAccess in $app.RequiredResourceAccess) {
            $resource = Get-MgServicePrincipal -Filter "appId eq '$($resourceAccess.ResourceAppId)'"
            
            if ($resource) {
                # Handle Application Permissions (AppRoles)
                $appRoles = $resourceAccess.ResourceAccess | Where-Object { $_.Type -eq "Role" }
                foreach ($permission in $appRoles) {
                    try {
                        $appRole = $resource.AppRoles | Where-Object { $_.Id -eq $permission.Id }
                        if ($appRole) {
                            $params = @{
                                PrincipalId = $servicePrincipal.Id
                                ResourceId = $resource.Id
                                AppRoleId = $permission.Id
                            }
                            
                            New-MgServicePrincipalAppRoleAssignment -ServicePrincipalId $servicePrincipal.Id -BodyParameter $params | Out-Null
                        }
                    }
                    catch {
                        if (-not ($_.Exception.Message -like "*Permission entry already exists*")) {
                            $hasError = $true
                            Write-StatusMessage "Failed to grant application permission: $_" -Color Red
                        }
                    }
                }

                # Handle Delegated Permissions (OAuth2PermissionScopes)
                $delegatedPermissions = $resourceAccess.ResourceAccess | Where-Object { $_.Type -eq "Scope" }
                if ($delegatedPermissions) {
                    try {
                        $scopes = @()
                        foreach ($permission in $delegatedPermissions) {
                            $scope = $resource.OAuth2PermissionScopes | Where-Object { $_.Id -eq $permission.Id }
                            if ($scope) {
                                $scopes += $scope.Value
                            }
                        }

                        if ($scopes.Count -gt 0) {
                            $params = @{
                                ClientId = $servicePrincipal.Id
                                ConsentType = "AllPrincipals"
                                ResourceId = $resource.Id
                                Scope = $scopes -join ' '
                            }
                            
                            $existingGrant = Get-MgOauth2PermissionGrant -Filter "clientId eq '$($servicePrincipal.Id)' and resourceId eq '$($resource.Id)'"
                            if ($existingGrant) {
                                $updatedScopes = ($existingGrant.Scope -split ' ' | Select-Object -Unique) + ($scopes | Select-Object -Unique)
                                $uniqueScopes = $updatedScopes | Select-Object -Unique
                                Update-MgOauth2PermissionGrant -OAuth2PermissionGrantId $existingGrant.Id -BodyParameter @{
                                    Scope = $uniqueScopes -join ' '
                                } | Out-Null
                            } else {
                                New-MgOauth2PermissionGrant -BodyParameter $params | Out-Null
                            }
                        }
                    }
                    catch {
                        $hasError = $true
                        Write-StatusMessage "Failed to grant delegated permissions: $_" -Color Red
                    }
                }
            }
        }
        
        if (-not $hasError) {
            Write-StatusMessage "Admin consent granted successfully." -Color Green
        }
    }
    else {
        Write-StatusMessage "Admin consent skipped." -Color Yellow
    }
}

# Main Script
try {
    Write-StatusMessage "Deployment started..."
    
    # Initialize environment
    Import-RequiredModules
    
    # Connect to Microsoft Graph with required permissions
    try {
        Write-StatusMessage "Connecting to Microsoft Graph..." -Color Cyan
        Disconnect-MgGraph -ErrorAction SilentlyContinue | Out-Null
        Connect-MgGraph -Scopes @(
            "Application.ReadWrite.All",
            "Directory.Read.All",
            "Directory.AccessAsUser.All"
        ) -NoWelcome -UseDeviceCode -ContextScope Process

        $context = Get-MgContext
        Write-StatusMessage "Connected to Microsoft Graph" -Color Green
        Write-StatusMessage "Account: $($context.Account)" -Color Cyan
        Write-StatusMessage "Environment: $($context.Environment)" -Color Cyan
        Write-StatusMessage "Tenant ID: $($context.TenantId)" -Color Cyan
        Write-StatusMessage "Scopes: $($context.Scopes -join ', ')" -Color Cyan

        if (-not (Get-MgContext)) {
            throw "Failed to establish Microsoft Graph connection"
        }
    } catch {
        Write-StatusMessage "Failed to connect to Microsoft Graph: $_" -Color Red
        throw
    }
    
    # Get input parameters
    $displayName = Read-Host -Prompt "Enter the Microsoft Entra ID app name (ex: Moodle plugin)"
    $moodleUrl = Get-MoodleUrl
    
    Write-Progress -Activity "Configuring application" -Status "Creating application" -PercentComplete 0
    
    # Setup URLs
    $replyUrls = @(
        $moodleUrl,
        "${moodleUrl}auth/oidc/",
        "${moodleUrl}local/o365/sso_end.php"
    )
    
    # Create application
    $requiredResourceAccess = Get-Resources
    
    $appParams = @{
        DisplayName = $displayName
        RequiredResourceAccess = $requiredResourceAccess
        Web = @{
            RedirectUris = $replyUrls
            HomePageUrl = $moodleUrl
            LogoutUrl = "${moodleUrl}auth/oidc/logout.php"
        }
    }
    
    $app = Invoke-WithRetry -OperationName "Application creation" {
        # Verify connection is valid
        $context = Get-MgContext
        if (-not $context -or -not $context.Account) {
            throw "Microsoft Graph connection is not available. Please ensure you are connected."
        }
        
        # Test connection with error handling
        try {
            # Use a simple test that doesn't require additional permissions
            $null = Get-MgContext
            if (-not (Get-MgContext).Account) {
                throw "Authentication context is invalid"
            }
        }
        catch {
            Write-StatusMessage "Connection test failed, attempting to reconnect..." -Color Yellow

            # Clean disconnect and reconnect
            try {
                Disconnect-MgGraph -ErrorAction SilentlyContinue | Out-Null
                Start-Sleep -Seconds 2

                Connect-MgGraph -Scopes @(
                    "Application.ReadWrite.All",
                    "Directory.Read.All",
                    "Directory.AccessAsUser.All"
                ) -NoWelcome -UseDeviceCode -ContextScope Process -ErrorAction Stop
                
                Start-Sleep -Seconds 3
                
                if (-not (Get-MgContext).Account) {
                    throw "Failed to establish valid connection"
                }
            }
            catch {
                throw "Unable to establish Microsoft Graph connection: $_"
            }
        }
        
        # Create application with basic parameters first
        $basicParams = @{
            DisplayName = $appParams.DisplayName
            RequiredResourceAccess = $appParams.RequiredResourceAccess
        }
        
        Write-StatusMessage "Creating application with display name: $($basicParams.DisplayName)" -Color Cyan
        
        try {
            $newApp = New-MgApplication @basicParams
            
            if (-not $newApp -or -not $newApp.Id) {
                throw "Application creation failed - no application object returned"
            }
            
            # Wait a moment before updating
            Start-Sleep -Seconds 2
            
            # Update with web configuration separately
            Write-StatusMessage "Updating application with web configuration..." -Color Cyan
            Update-MgApplication -ApplicationId $newApp.Id -Web $appParams.Web
            
            return $newApp
        }
        catch {
            if ($_.Exception.Message -like "*DeviceCodeCredential*") {
                throw "Authentication failed. Please ensure you complete the device code authentication process."
            }
            throw
        }
    }

    # Add the new Enterprise Application code here, before the API access configuration
    Write-Progress -Activity "Configuring application" -Status "Creating Enterprise Application" -PercentComplete 20

    $servicePrincipal = Invoke-WithRetry -OperationName "Enterprise Application creation" {
        # Check if service principal already exists
        $existingSP = Get-MgServicePrincipal -Filter "appId eq '$($app.AppId)'"
        
        if (-not $existingSP) {
            Write-StatusMessage "Creating Enterprise Application..." -Color Cyan
            New-MgServicePrincipal -AppId $app.AppId -Tags @("WindowsAzureActiveDirectoryIntegratedApp")
        } else {
            Write-StatusMessage "Enterprise Application already exists" -Color Cyan
            $existingSP
        }
    }

    Write-StatusMessage "Enterprise Application ID: $($servicePrincipal.Id)"
    
    Write-StatusMessage "Successfully registered app with ID: $($app.AppId)"
    
    # Configure API access
    Write-Progress -Activity "Configuring application" -Status "Configuring API access" -PercentComplete 30

    # Set requestedAccessTokenVersion to 2 first to avoid domain verification issues
    Write-StatusMessage "Setting access token version to 2..." -Color Cyan
    Invoke-WithRetry -OperationName "Set access token version" {
        Update-MgApplication -ApplicationId $app.Id -Api @{
            RequestedAccessTokenVersion = 2
        }
    }
    Write-StatusMessage "Access token version set successfully" -Color Green

    # Wait a moment for the change to propagate
    Start-Sleep -Seconds 2

    # Set Application ID URI using the format api://[MOODLE_URL]/[APP_ID]
    # Remove https:// prefix and trailing slash from Moodle URL
    $moodleUrlFormatted = $moodleUrl -replace '^https://', '' -replace '/$', ''
    $identifierUris = "api://$moodleUrlFormatted/$($app.AppId)"
    Write-StatusMessage "Setting Application ID URI: $identifierUris" -Color Cyan

    $apiParams = @{
        ApplicationId = $app.Id
        IdentifierUris = @($identifierUris)
        Api = @{
            RequestedAccessTokenVersion = 2
            Oauth2PermissionScopes = @(
                @{
                    AdminConsentDescription = "Allows Teams to call the app's web APIs as the current user"
                    AdminConsentDisplayName = "Teams can access the user's profile"
                    UserConsentDescription = "Enable Teams to call this app's APIs with the same rights as the user"
                    UserConsentDisplayName = "Teams can access the user profile and make requests on the user's behalf"
                    IsEnabled = $true
                    Type = "User"
                    Value = "access_as_user"
                    Id = [Guid]::NewGuid()
                }
            )
        }
    }

    Invoke-WithRetry -OperationName "API configuration" {
        Update-MgApplication @apiParams
    }
    Write-StatusMessage "API configuration completed successfully" -Color Green
    
    # Add current user as owner
    Write-Progress -Activity "Configuring application" -Status "Adding owner" -PercentComplete 60
    
    $context = Get-MgContext
    $user = Get-MgUser -UserId $context.Account
    
    Invoke-WithRetry -OperationName "Owner addition" {
        New-MgApplicationOwnerByRef -ApplicationId $app.Id -OdataId "https://graph.microsoft.com/v1.0/directoryObjects/$($user.Id)"
    }
    
    # Generate client secret
    Write-Progress -Activity "Configuring application" -Status "Generating credentials" -PercentComplete 80
    
    $secret = Invoke-WithRetry -OperationName "Secret creation" {
        Add-MgApplicationPassword -ApplicationId $app.Id
    }
    
    # Update logo (optional - may fail due to content-type issues)
    $logoPath = Join-Path (Get-Location) 'Assets\moodle-logo.jpg'
    if (Test-Path $logoPath) {
        Write-StatusMessage "Attempting to set application logo..." -Color Cyan
        try {
            Set-MgApplicationLogo -ApplicationId $app.Id -InFile $logoPath -ErrorAction Stop
            Write-StatusMessage "Application logo set successfully" -Color Green
        } catch {
            Write-StatusMessage "Note: Logo upload skipped (content-type issue). You can upload it manually in the Azure portal." -Color Yellow
        }
    }
    
    # Grant admin consent if requested
    Grant-AdminConsent -ApplicationId $app.Id
    
    # Configure optional claims
    $optionalClaimsPath = Join-Path (Get-Location) 'Json\EntraIDOptionalClaims.json'
    if (Test-Path $optionalClaimsPath) {
        try {
            $optionalClaimsJson = Get-Content $optionalClaimsPath | ConvertFrom-Json
            
            # Create the OptionalClaims object
            $optionalClaimsObj = [Microsoft.Graph.PowerShell.Models.MicrosoftGraphOptionalClaims]::new()
            
            # Process ID Token claims
            if ($optionalClaimsJson.idToken) {
                $optionalClaimsObj.IdToken = @()
                foreach ($claim in $optionalClaimsJson.idToken) {
                    $optionalClaim = [Microsoft.Graph.PowerShell.Models.MicrosoftGraphOptionalClaim]::new()
                    $optionalClaim.Name = $claim.name
                    $optionalClaim.Source = $claim.source
                    $optionalClaim.Essential = $claim.essential
                    $optionalClaim.AdditionalProperties = $claim.additionalProperties
                    $optionalClaimsObj.IdToken += $optionalClaim
                }
            }

            # Process Access Token claims
            if ($optionalClaimsJson.accessToken) {
                $optionalClaimsObj.AccessToken = @()
                foreach ($claim in $optionalClaimsJson.accessToken) {
                    $optionalClaim = [Microsoft.Graph.PowerShell.Models.MicrosoftGraphOptionalClaim]::new()
                    $optionalClaim.Name = $claim.name
                    $optionalClaim.Source = $claim.source
                    $optionalClaim.Essential = $claim.essential
                    $optionalClaim.AdditionalProperties = $claim.additionalProperties
                    $optionalClaimsObj.AccessToken += $optionalClaim
                }
            }

            # Process SAML2 Token claims
            if ($optionalClaimsJson.saml2Token) {
                $optionalClaimsObj.Saml2Token = @()
                foreach ($claim in $optionalClaimsJson.saml2Token) {
                    $optionalClaim = [Microsoft.Graph.PowerShell.Models.MicrosoftGraphOptionalClaim]::new()
                    $optionalClaim.Name = $claim.name
                    $optionalClaim.Source = $claim.source
                    $optionalClaim.Essential = $claim.essential
                    $optionalClaim.AdditionalProperties = $claim.additionalProperties
                    $optionalClaimsObj.Saml2Token += $optionalClaim
                }
            }

            Update-MgApplication -ApplicationId $app.Id -OptionalClaims $optionalClaimsObj
            Write-StatusMessage "Microsoft Entra ID optional claims updated" -Color Green
        }
        catch {
            Write-StatusMessage "Failed to add Mcrosoft Entra ID optional claims: $_" -Color Red
        }
    }
    
    # Configure Teams integration
    Write-Progress -Activity "Configuring application" -Status "Configuring Teams integration" -PercentComplete 90
    
    # Get the access_as_user scope
    $scope = Invoke-WithRetry -OperationName "Get scope" {
        $updatedApp = Get-MgApplication -ApplicationId $app.Id
        $updatedApp.Api.Oauth2PermissionScopes | Where-Object { $_.Value -eq 'access_as_user' }
    }
    
    if ($scope) {
        $preAuthorizedApps = @(
            @{
                AppId = '1fec8e78-bce4-4aaf-ab1b-5451cc387264'  # Teams Rich Client
                DelegatedPermissionIds = @($scope.Id)
            },
            @{
                AppId = '5e3ce6c0-2b1f-4285-8d4b-75ee78787346'  # Teams Web Client
                DelegatedPermissionIds = @($scope.Id)
            }
        )
        
        Invoke-WithRetry -OperationName "Teams pre-authorization" {
            Update-MgApplication -ApplicationId $app.Id -Api @{
                PreAuthorizedApplications = $preAuthorizedApps
            }
        }
    }
    
    # Output results
    Write-Progress -Activity "Configuring application" -Completed
    Write-StatusMessage "`nApplication configuration completed successfully!"
    Write-StatusMessage "Application (Client) ID: $($app.AppId)"
    Write-StatusMessage "Client Secret: $($secret.SecretText)"
    Write-StatusMessage "Please save these credentials securely."
}
catch {
    Write-StatusMessage "Deployment failed: $_" -Color Red
    exit 1
}
