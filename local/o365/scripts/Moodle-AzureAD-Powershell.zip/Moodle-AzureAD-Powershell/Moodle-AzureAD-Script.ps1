<#
    File: Moodle-AzureAD-Script.ps1
#>

# Install necessary modules
Install-Module AzureAD -AllowClobber -Scope CurrentUser
Install-Module AzureRM -AllowClobber -Scope CurrentUser

#Overarching requirement - log into Azure first!
Connect-AzureAD

<#
.DESCRIPTION 

This function will be able to create an array of type RequiredResourceAccess which will be then passed to the New-AzureADApplication cmdlet
#>
function Get-Resources
{
    [Microsoft.Open.AzureAD.Model.RequiredResourceAccess[]] $outputArray = @();
    
    $localPath = Get-Location
    $jsonPath = -Join($localPath,'\Json\permissions.json');
    $jsonObj = (New-Object System.Net.WebClient).DownloadString($jsonPath) | ConvertFrom-Json;

    # Output the number of objects to push into the array outputArray
    Write-Host 'From the json path:'$jsonPath', we can find' $jsonObj.requiredResourceAccess.length'attributes to populate';

    for ($i = 0; $i -lt $jsonObj.requiredResourceAccess.length; $i++) {
        
        # Step A - Create a new object fo the type RequiredResourceAccess
        $reqResourceAccess = New-Object -TypeName Microsoft.Open.AzureAD.Model.RequiredResourceAccess; 

        # Step B - Straightforward setting the ResourceAppId accordingly
        $reqResourceAccess.ResourceAppId = $jsonObj.requiredResourceAccess[$i].resourceAppId;

        # Step C - Having to set the ResourceAccess carefully
        if ($jsonObj.requiredResourceAccess[$i].resourceAccess.length -gt 1)
        {
            $reqResourceAccess.ResourceAccess = $jsonObj.requiredResourceAccess[$i].resourceAccess;
        }
        else
        {
            $reqResourceAccess.ResourceAccess = $jsonObj.requiredResourceAccess[$i].resourceAccess[0];
        }

        # Step D - Add the element to the array
        $outputArray += $reqResourceAccess;
    }

    $outputArray;
}

# Step 1 - Getting the necessary information
$displayName = Read-Host -Prompt "Enter the AAD app name (ex: Moodle plugin)"
$moodleDomain = Read-Host -Prompt "Enter the URL of your Moodle server (ex: https://www.moodleserver.com)"

if ($moodleDomain -notmatch '.+?\/$')
{
    $moodleDomain += '/'
}

# Step 2 - Construct the reply URLs
$ssoEndUrl = $moodleDomain + 'local/o365/sso_end.php'
$ssoUrl = $moodleDomain + 'local/o365/sso.php'
$botFrameworkUrl = 'https://token.botframework.com/.auth/web/redirect'
$authUrl = $moodleDomain + 'auth/oidc/'

$replyUrls = ($ssoEndUrl, $ssoUrl, $botFrameworkUrl, $authUrl)

# Step 3 - Compile the Required Resource Access object
[Microsoft.Open.AzureAD.Model.RequiredResourceAccess[]] $requiredResourceAccess = Get-Resources

# Step 4 - Making sure to officially register the application
$appVars = New-AzureADApplication -DisplayName $displayName ReplyUrls $replyUrls -RequiredResourceAccess $requiredResourceAccess

# Step 5 - Taking the object id generated in Step 2, create a new Password
$pwdVars = New-AzureADApplicationPasswordCredential -ObjectId $appVars.ObjectId

# Step 5a - Updating the logo for the Azure AD app
$location = Get-Location
$imgLocation = -Join($location, '\Assets\moodle-logo.jpg')

Set-AzureADApplicationLogo -ObjectId $appVars.ObjectId -FilePath $imgLocation

# Step 6 - Write out the newly generated app Id and azure app password
Write-Host 'Your Application ID: '$appVars.AppId
Write-Host 'Your Application Key: '$pwdVars.Value